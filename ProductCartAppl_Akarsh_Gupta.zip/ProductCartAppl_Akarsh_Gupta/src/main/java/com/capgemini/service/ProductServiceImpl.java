package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.beans.Products;
import com.capgemini.exception.DuplicateProductIDException;
import com.capgemini.exception.InvalidProductIDException;
import com.capgemini.dao.IProductRepo;
					
											
@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductRepo prorepo;

	@Override
	public Products createProduct(Products products) throws DuplicateProductIDException {

		if (prorepo.findProduct(products.getId()) == null) {

			return prorepo.save(products);

		}
		throw new DuplicateProductIDException("Product Id already exists");
	}

	@Override
	public Products updateProduct(Products products, String id) throws InvalidProductIDException {

		if (prorepo.findProduct(id) == null) {

			throw new InvalidProductIDException("Product Id does not exist");

		}
		return prorepo.updateProduct(products, id);

	}

	@Override
	public boolean deleteProduct(String id) throws InvalidProductIDException {

		if (prorepo.findProduct(id) == null) {
			throw new InvalidProductIDException("Product ID does not exist");
		}
		return prorepo.deleteProduct(id);
	}

	@Override
	public List<Products> viewProducts() {
		return (prorepo.findAll());
	}

	@Override
	public Products findProduct(String id) throws InvalidProductIDException {

		if (prorepo.findProduct(id) == null) {

			throw new InvalidProductIDException("Product ID does not exist");
		}

		return prorepo.findProduct(id);

	}

}
package com.capgemini.service;

import java.util.List;

import com.capgemini.beans.Products;
import com.capgemini.exception.DuplicateProductIDException;
import com.capgemini.exception.InvalidProductIDException;
											
public interface IProductService {
										//Interface for ProductService class 
	public Products createProduct(Products products) throws DuplicateProductIDException;

	public Products updateProduct(Products products, String id) throws InvalidProductIDException;

	public boolean deleteProduct(String id) throws InvalidProductIDException;

	public List<Products> viewProducts();

	public Products findProduct(String id) throws InvalidProductIDException;

}

package com.capgemini.exception;

public class DuplicateProductIDException extends Exception {

	/**
	 * 									
	 */
	private static final long serialVersionUID = 1L;

	public DuplicateProductIDException(String message) {		// raise an exception when the product ID already exists

		super(message);

	}
}

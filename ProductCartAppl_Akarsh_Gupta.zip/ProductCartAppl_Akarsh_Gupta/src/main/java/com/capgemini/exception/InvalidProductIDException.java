package com.capgemini.exception;

public class InvalidProductIDException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public InvalidProductIDException(String message){			 //InvalidProductIDException
		
		super(message);
		
	}

}

package com.capgemini.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;

@Entity
@Table(name = "product")
public class Products {
	
	
								
	@Id
	@Pattern(regexp = "[A-Za-z ]{1}[0]{1}[0-9]{1}", message = "Sorry Product id is not valid.")	
	private String id;			
								//Product id must be of 3 characters starts with a lower or upper character and ends with a digit having 0 
							
	
	@Pattern(regexp = "[A-Za-z ]{2,20}", message = "Sorr Product name is not as given requirement.")
	private String name;		
								//Product Name can be in digit or alphabetic
							
	@NotNull(message = "Product model cannot be null.")
	@Pattern(regexp = "[A-Za-z0-9 ]+", message = "Sorry Product model is not as given requirement.")
	private String model;		
	
								//Product Name must be in digit or alphabetic

	
	@Positive(message = "Price must be positive.")
	private int price;			
								//Price must be Positive  

	
	
	public String getId() {		
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}


}

package com.capgemini.dao;

import java.util.List;

import com.capgemini.beans.Products;
										//Interface of ProductRepository class
public interface IProductRepo {

	public Products save(Products products);

	public Products findProduct(String id);

	public boolean deleteProduct(String id);

	public List<Products> findAll();

	public Products updateProduct(Products products, String id);
}

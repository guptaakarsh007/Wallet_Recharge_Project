package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.beans.Products;
import com.capgemini.dao.IProductRepo;
								/*Repository class*/
@Repository
@Transactional
public class ProductRepoImpl implements IProductRepo {
														/*Implementation of the Repository class*/
	@PersistenceContext
	private EntityManager entitymanager;

	@Override
	public Products save(Products products) {			/*find the product in the database */
		entitymanager.persist(products);
		return findProduct(products.getId());

	}

	@Override
	public Products findProduct(String id) {			/*find the product from the database */
		Products products = new Products();
		products = entitymanager.find(Products.class, id);
		return products;
	}
	
	@Override
	public List<Products> findAll() {					/*view all the products from the database */

		return entitymanager.createQuery("select p from Products p" ,Products.class).getResultList();
	}

	@Override
	public Products updateProduct(Products products, String id) {
		
														/*update the product in the database */

		Products prod = entitymanager.find(Products.class, id);
		prod.setName(products.getName());
		prod.setModel(products.getModel());
		prod.setPrice(products.getPrice());

		return prod;
	}

	@Override
	public boolean deleteProduct(String id) {			/*delete the product in the database */

		Products prod = entitymanager.find(Products.class, id);
		entitymanager.remove(prod);
		return true;
	}

}
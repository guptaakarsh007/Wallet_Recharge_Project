package com.capgemini.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.beans.Products;
import com.capgemini.exception.DuplicateProductIDException;
import com.capgemini.exception.InvalidProductIDException;
import com.capgemini.service.IProductService;

@RestController							
@Validated
public class ProductController {

	@Autowired							//Making Object Reference using Autowired annotation
	IProductService proservice;

	@RequestMapping(method = RequestMethod.POST, value = "/addproduct")			//add product using get request from POST MAN
	public Products createProduct(@Valid @RequestBody Products products) throws DuplicateProductIDException {
		return proservice.createProduct(products);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/products/{id}")		//update product using id 
	public Products updateProduct(@RequestBody Products products, @PathVariable String id)
			throws InvalidProductIDException {
		return proservice.updateProduct(products, id);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/deleteproduct/{id}")	//delete product using id
	public boolean deleteProduct(@PathVariable String id) throws InvalidProductIDException {
		return proservice.deleteProduct(id);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/products")		//Viewing of all products List
	public List<Products> viewProducts() {
		return (List<Products>) proservice.viewProducts();
	}

	@RequestMapping(method = RequestMethod.GET, value = "/findproduct/{id}")	//find product using id
	public Products findProduct(
			@Valid @Pattern(regexp = "[A-Za-z]{1}[0]{1}[0-9]{1}", message = "Product id is not valid.") @PathVariable String id)
			throws InvalidProductIDException {
		return proservice.findProduct(id);
	}

}
